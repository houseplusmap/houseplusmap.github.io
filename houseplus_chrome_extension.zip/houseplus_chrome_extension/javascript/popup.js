// Copyright 2018 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.
$(function ($) {
  const url = 'https://zihenglincee.appspot.com/lookup';
  // const url = 'http://127.0.0.1:5000/lookup';

  // chrome storage items
  chrome.storage.local.get('address', function (houseplus) {
    $('#address').val(houseplus.address);
  });
  chrome.storage.local.get('original_sqft', function (houseplus) {
    $('#original_sqft').val(houseplus.original_sqft);
  });
  chrome.storage.local.get('zoning_code', function (houseplus) {
    $('#zoning_code').val(houseplus.zoning_code);
  });
  chrome.storage.local.get('new_sqft', function (houseplus) {
    $('#new_sqft').val(houseplus.new_sqft);
  });

  // Activate tabbing
  $('#main-nav a').click(function (e) {
    e.preventDefault();
    $(this).tab('show');
  });

  //Calculate button
  $('#address_submit').click(function () {
    var $this = $(this)
    $this.button('loading');

    //Get variables
    var address = $('#address').val();
    var sqft = $('#original_sqft').val();
    chrome.storage.local.set({ 'address': address });
    chrome.storage.local.set({ 'original_sqft': sqft });

    //Clear Fields
    $('#zoning_code').val('');
    $('#new_sqft').val('');

    //Http post
    var http = new XMLHttpRequest();
    http.open('POST', url, true);
    http.setRequestHeader('Content-type', 'application/json');
    http.onreadystatechange = function () {
      if (http.readyState == 4 && http.status == 200) {
        var res = JSON.parse(this.responseText);
        $('#zoning_code').val(res.zoning_class);
        $('#new_sqft').val(res.parcel_shape_area);
        chrome.storage.local.set({ 'zoning_code': res.zoning_class });
        chrome.storage.local.set({ 'new_sqft': res.parcel_shape_area });
        $this.button('reset');
      }
    }
    http.send(
      JSON.stringify({ "address": address, "building_size": sqft })
    );
  });

  //From Redfin button
  $('#from_redfin').click(function () {
    //Clear Fields
    $('#address').val('');
    $('#original_sqft').val('');
    $('#zoning_code').val('');
    $('#new_sqft').val('');
    chrome.tabs.executeScript(null, {
      file: "javascript/getPageSourceIndividual.js"
    }, function () {
      if (chrome.runtime.lastError) {
        $('#message').innerText = 'There was an error injecting script : \n' +
          chrome.runtime.lastError.message;
      }
    });
  });


  //From Redfin button
  $('#from_redfin_list').click(function () {
    chrome.tabs.executeScript(null, {
      file: "javascript/getPageSourceList.js"
    }, function () {
      if (chrome.runtime.lastError) {
        $('#message').innerText = 'There was an error injecting script : \n' +
          chrome.runtime.lastError.message;
      }
    });
  });

  // Address and home sqft listener
  chrome.runtime.onMessage.addListener(function (request, sender) {

    function sndReq(content, index) {
      var http = new XMLHttpRequest();
      http.open('POST', url, true);
      http.setRequestHeader('Content-type', 'application/json');
      http.onreadystatechange = function () { if (http.readyState == 4 && http.status == 200) { xhrHandler(http, index) } };
      http.send(content);
    };
    function xhrHandler(xhr, index) {
      var res = JSON.parse(xhr.responseText)
      document.getElementById('redfintable_tbody_zoning_cell' + String(index)
      ).innerHTML = res.zoning_class;
      document.getElementById('redfintable_tbody_expansion_cell' + String(index)
      ).innerHTML = res.parcel_shape_area;
    };

    if (request.action == "getAddressFromDOM") {
      $('#address').val(request.source.address);
    }
    if (request.action == "getHouseInfoFromDOM") {
      $('#original_sqft').val(request.source.home_sqft);
    }

    if (request.action == "getHouseInfoListFromDOM") {
      // console.log(request.source.href_list);
      var redfin_table = document.getElementById('redfintable_tbody');
      for (var i = 0; i < request.source.address_list.length; i++) {

        var row = redfin_table.insertRow(-1);
        var id_cell = row.insertCell(0);
        var address_cell = row.insertCell(1);
        var sqft_cell = row.insertCell(2);
        var zoning_cell = row.insertCell(3);
        var expansion_cell = row.insertCell(4);
        var address = request.source.address_list[i];
        var sqft = request.source.property_size_list[i];
        
        // row.href = request.source.href_list[i];
        // id_cell.href = request.source.href_list[i];
        id_cell.innerHTML = i + 1;
        address_cell.innerHTML = address;
        sqft_cell.innerHTML = sqft;
        zoning_cell.id = 'redfintable_tbody_zoning_cell' + String(i);
        zoning_cell.innerHTML = '...';
        expansion_cell.id = 'redfintable_tbody_expansion_cell' + String(i);
        expansion_cell.innerHTML = '...';

      }

      // Send request for each row
      for (var i = 0; i < request.source.address_list.length; i++) {
        sndReq(JSON.stringify({ "address": request.source.address_list[i], "building_size": 100 }),
          String(i));
      }
    }
  });
});

