function getHouseInfoListFromDOM(document_root) {
    var address_list = [],
        property_size_list = [],
        href_list = [];
    node = document_root.querySelectorAll('[class="bottomV2"]');
    // console.log(node)
    for (var i = 0; i < node.length; i++) {
        var item = node[i];
        // console.log(node[i]);
        address_list.push(
            item.querySelector('[data-rf-test-id="abp-homeinfo-homeaddress"]'
            ).innerText);
        property_size_list.push(
            item.querySelector('[class="HomeStatsV2 font-size-small"]'
            ).childNodes[2].innerText);
        href_list.push(item.parentNode.href);
    }

    return {
        'address_list': address_list,
        'property_size_list': property_size_list,
        'href_list': href_list
    };

    // if (home_table_node){
    //     return {
    //         'home_sqft': home_node.querySelector(
    //             '[data-rf-test-id="abp-sqFt"]').querySelector(
    //                 '[class="statsValue"]').childNodes[0].nodeValue.replace(',', '')
    //     }
    // }
    // return Null
}

chrome.runtime.sendMessage({
    action: "getHouseInfoListFromDOM",
    source: getHouseInfoListFromDOM(document)
});