function getAddressFromDOM(document_root) {
    var address = '',
        street_node = document_root.querySelector('[data-rf-test-id="abp-streetLine"]'),
        city_node = document_root.querySelector('[data-rf-test-id="abp-cityStateZip"]'),
        home_node = document_root.querySelector('[data-rf-test-id="abp-homeinfo-homemainstats"]');
    address += street_node.childNodes[0].nodeValue;
    address += city_node.querySelector('[class="locality"]').childNodes[0].nodeValue;
    address += ' '
    address += city_node.querySelector('[class="region"]').childNodes[0].nodeValue;
    address += ' '
    address += city_node.querySelector('[class="postal-code"]').childNodes[0].nodeValue;
    return {
        'address': address
    };
}

function getHouseInfoFromDOM(document_root) {
    var home_node = document_root.querySelector('[data-rf-test-id="abp-homeinfo-homemainstats"]');
    if (home_node){
        return {
            'home_sqft': home_node.querySelector(
                '[data-rf-test-id="abp-sqFt"]').querySelector(
                    '[class="statsValue"]').childNodes[0].nodeValue.replace(',', '')
        }
    }
    return Null
}

chrome.runtime.sendMessage({
    action: "getAddressFromDOM",
    source: getAddressFromDOM(document)
});


chrome.runtime.sendMessage({
    action: "getHouseInfoFromDOM",
    source: getHouseInfoFromDOM(document)
});